# Viewchanger
Change view of your scratch 3.0 to 2.0 and reverse! It's an extension for google chrome
## Viewchanger was previously created by @AANNTTOONNII and then upgraded by @Erixo and then upgraded by @AANNTTOONNII :) - find us on Scratch:
### https://scratch.mit.edu/users/Erixo/
### https://scratch.mit.edu/users/aannttoonnii/
